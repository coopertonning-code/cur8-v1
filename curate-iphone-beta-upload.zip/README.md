# curATE v2 Prototype

This is the second clickable prototype for curATE, refined through the marketing direction.

Open `index.html` in a browser to try it. The prototype includes:

- First-run onboarding
- Chef-first browsing with Signature Chefs, New Near You, Table Shares, and Popular for Gatherings
- List and map-style discovery
- Chef profiles with badges, menus, Why I Cook, and review-tag signals
- Request-first planning flow
- Wallet and virtual gift card concept
- Profile-based host list entry
- curATE visual direction with olive actions, warm earth tones, and a beta food/gathering icon
- iPhone home-screen app support through Safari

This is an investor-ready prototype, not a production app yet. Real payments, background checks, app-store setup, and legal policy work come after the prototype direction is validated.

## Install on iPhone

1. Open the GitHub Pages link in Safari.
2. Tap the Share button.
3. Tap Add to Home Screen.
4. Name it curATE and tap Add.

This creates a private-feeling beta app icon on your phone. It is not an App Store/TestFlight app yet, but it is the fastest way to demo curATE from an iPhone.
